import cv2
import customtkinter as ctk
from tkinter import filedialog
from PIL import Image, ImageTk
import numpy as np

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

class DIPApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Digital Image Processing Studio")
        self.geometry("900x600")

        # Variabel penyimpanan
        self.original_image = None
        self.processed_image = None

        # Frame kiri untuk kontrol
        control_frame = ctk.CTkFrame(self, width=200, corner_radius=15)
        control_frame.pack(side="left", fill="y", padx=10, pady=10)

        ctk.CTkLabel(control_frame, text="DIP Studio", font=("Arial", 20, "bold")).pack(pady=20)
        ctk.CTkButton(control_frame, text="📂 Pilih Gambar", command=self.open_image).pack(pady=10)

        ctk.CTkLabel(control_frame, text="Efek Pengolahan Citra:", font=("Arial", 14)).pack(pady=15)
        ctk.CTkButton(control_frame, text="Grayscale", command=self.to_grayscale).pack(pady=5)
        ctk.CTkButton(control_frame, text="Gaussian Blur", command=self.to_blur).pack(pady=5)
        ctk.CTkButton(control_frame, text="Edge Detection", command=self.to_edge).pack(pady=5)
        ctk.CTkButton(control_frame, text="Reset", command=self.reset_image).pack(pady=20)

        self.image_frame = ctk.CTkFrame(self, corner_radius=15)
        self.image_frame.pack(side="right", expand=True, fill="both", padx=10, pady=10)

        self.label_original = ctk.CTkLabel(self.image_frame, text="Citra Asli akan tampil di sini")
        self.label_original.pack(side="left", expand=True, padx=10)
        self.label_processed = ctk.CTkLabel(self.image_frame, text="Citra Hasil akan tampil di sini")
        self.label_processed.pack(side="right", expand=True, padx=10)

    def open_image(self):
        path = filedialog.askopenfilename(title="Pilih Gambar", filetypes=[("Image Files", "*.jpg *.jpeg *.png")])
        if not path:
            return
        self.original_image = cv2.imread(path)
        self.processed_image = self.original_image.copy()
        self.show_images()

    def show_images(self):
        if self.original_image is None:
            return

        def cv_to_tk(img):
            img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            img_pil = Image.fromarray(img_rgb)
            img_pil = img_pil.resize((350, 350))
            return ImageTk.PhotoImage(img_pil)

        img_tk1 = cv_to_tk(self.original_image)
        img_tk2 = cv_to_tk(self.processed_image)

        self.label_original.configure(image=img_tk1, text="")
        self.label_original.image = img_tk1
        self.label_processed.configure(image=img_tk2, text="")
        self.label_processed.image = img_tk2

    def to_grayscale(self):
        if self.original_image is None:
            return
        gray = cv2.cvtColor(self.original_image, cv2.COLOR_BGR2GRAY)
        self.processed_image = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
        self.show_images()

    def to_blur(self):
        if self.original_image is None:
            return
        self.processed_image = cv2.GaussianBlur(self.original_image, (15, 15), 0)
        self.show_images()

    def to_edge(self):
        if self.original_image is None:
            return
        gray = cv2.cvtColor(self.original_image, cv2.COLOR_BGR2GRAY)
        edges = cv2.Canny(gray, 100, 200)
        self.processed_image = cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)
        self.show_images()

    def reset_image(self):
        if self.original_image is not None:
            self.processed_image = self.original_image.copy()
            self.show_images()

if __name__ == "__main__":
    app = DIPApp()
    app.mainloop()

